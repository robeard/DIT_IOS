//
//  rbTableViewCell.h
//  rob
//
//  Created by Robert Byrne on 11/11/2014.
//  Copyright (c) 2014 Robert Byrne. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface rbTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *name;
@property (nonatomic, weak) IBOutlet UILabel *userName;
@property (nonatomic, weak) IBOutlet UILabel *time;
@property (nonatomic, weak) IBOutlet UIImageView *myImage;
@property (nonatomic, weak) IBOutlet UITextView *textView;



@end
