//
//  rbViewController.m
//  rob
//
//  Created by media temp on 04/11/2014.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import "rbViewController.h"
#import "rbTweet.h"

@interface rbViewController ()

@end

@implementation rbViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    _tableView.dataSource = self;
    
    rbTweet *tweet1 = [[rbTweet alloc] init];
    tweet1.name = @"rob";
    tweet1.username = @"robatron";
    tweet1.text = @"What up bitches!! Joined this thing for the craic. Yo";
    tweet1.image = [UIImage imageNamed: @"Small-mario"];
    
    rbTweet *tweet2 = [[rbTweet alloc] init];
    tweet2.name = @"jon";
    tweet2.username = @"sakuhdbvjksbv";
    tweet2.text = @"sjhdvb jsad vjsah vj vjh vjsd vjv ";
    tweet2.image = [UIImage imageNamed: @"Small-mario"];
    rbTweet *tweet3 = [[rbTweet alloc] init];
    tweet3.name = @"Bill";
    tweet3.username = @"Billybob";
    tweet3.text = @"jhvugv hv hbhbjh jhbjbhjbjhbjhbjbjhbjkhbhbjh jbjhbjh ";
    tweet3.image = [UIImage imageNamed: @"Small-mario"];
    rbTweet *tweet4 = [[rbTweet alloc] init];
    tweet4.name = @"Bill";
    tweet4.username = @"Billybob";
    tweet4.text = @"aejkbvh jdshvbjsw vjwd vjwhv ejlhvb alksdv sjldv ";
    tweet4.image = [UIImage imageNamed: @"Small-mario"];
    rbTweet *tweet5 = [[rbTweet alloc] init];
    tweet5.name = @"Rob";
    tweet5.username = @"robatron";
    tweet5.text = @"sadfkhsabfsbvjhds  jksh vjsbvjsad vjwdsv jsdv ";
    tweet5.image = [UIImage imageNamed: @"profilePic"];
    rbTweet *tweet6 = [[rbTweet alloc] init];
    tweet6.name = @"jon";
    tweet6.username = @"sakuhdbvjksbv";
    tweet6.text = @"dsfbdsbdsgfbsdbdfbdfbsdfb";
    tweet6.image = [UIImage imageNamed: @"Small-mario"];

    
    
    NSArray *tweets = @[tweet1, tweet2, tweet3, tweet4, tweet5, tweet6];
    _tweets = tweets;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_tweets count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"CellIdentifier";
    
    rbTableViewCell *cell = (rbTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    
    if (cell == nil) {
        cell = [[rbTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    rbTweet *tweet = [_tweets objectAtIndex:indexPath.row];
    
    [cell.name setText:tweet.name];
    [cell.userName setText:tweet.username];
    [cell.textView setText:tweet.text];
    [cell.myImage setImage:tweet.image];
    
    
    return cell;
}


@end
