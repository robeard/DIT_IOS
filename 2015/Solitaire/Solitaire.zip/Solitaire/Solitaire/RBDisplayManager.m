//
//  RBDisplayManager.m
//  Solitaire
//
//  Created by Robert Byrne on 24/03/2015.
//  Copyright (c) 2015 Wizardhat. All rights reserved.
//

#import "RBDisplayManager.h"

@interface RBDisplayManager ()

@property(strong, nonatomic) NSMutableArray* cols;

@end


@implementation RBDisplayManager

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _cols = [[NSMutableArray alloc]init];
        for (int i = 0; i<7; i++) {
            _cols[i] = [[NSMutableArray alloc] init];
        }
    }
    RBCard *card = [[RBCard alloc] init];
    [self addCard:card withColIndex:0];
    RBCard *card2 = [[RBCard alloc] init];
    [self addCard:card2 withColIndex:0];
    RBCard *card3 = [[RBCard alloc] init];
    [self addCard:card3 withColIndex:6];
    RBCard *card4 = [[RBCard alloc] init];
    [self addCard:card4 withColIndex:6];

    return self;
}

- (void)addCard:(RBCard*)card withColIndex:(int)index
{
    [_cols[index] addObject:card];
    [self refreshCardsView];
    
}

- (IBAction)handlePan:(UIPanGestureRecognizer *)recognizer {
    
    CGPoint translation = [recognizer translationInView:self];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self];
    switch (recognizer.state)
    {
        case UIGestureRecognizerStateBegan:
            [self began];
            break;
        case UIGestureRecognizerStateChanged:
            [self moved];
            break;
        case UIGestureRecognizerStateEnded:
            [self ended];
            break;
    }
    
}
-(void)began
{
    
    
}-(void)moved
{
    
    
}
-(void)ended
{
    

}

- (void)refreshCardsView
{
    int x = 3;
    int y = 20;
    for (int i = 0; i<7; i++) {
        for (int j = 0; j< [_cols[i] count]; j++) {
            UIImage *image = [UIImage imageNamed:@"Red_Card.png"];
            UIImageView *img = [[UIImageView alloc] initWithImage:image];
            img.frame = CGRectMake(x, y, 38, 80);
            [img setUserInteractionEnabled:true];
            UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
            [img addGestureRecognizer:panRecognizer];
            [self addSubview:img];

            y += 40;
            
        }
        y = 20;
        x += 44;
    }
}

@end
