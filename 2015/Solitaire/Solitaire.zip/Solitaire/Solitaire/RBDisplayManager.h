//
//  RBDisplayManager.h
//  Solitaire
//
//  Created by Robert Byrne on 24/03/2015.
//  Copyright (c) 2015 Wizardhat. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RBCard.h"

@import UIKit;

@interface RBDisplayManager : UIView


@end
