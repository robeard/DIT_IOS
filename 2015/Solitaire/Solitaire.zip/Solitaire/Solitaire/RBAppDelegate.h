//
//  RBAppDelegate.h
//  Solitaire
//
//  Created by Robert Byrne on 24/03/2015.
//  Copyright (c) 2015 Wizardhat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
