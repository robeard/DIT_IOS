//
//  main.m
//  Solitaire
//
//  Created by Robert Byrne on 24/03/2015.
//  Copyright (c) 2015 Wizardhat. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RBAppDelegate class]));
    }
}
