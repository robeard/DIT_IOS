//
//  RBViewController.m
//  Solitaire
//
//  Created by Robert Byrne on 24/03/2015.
//  Copyright (c) 2015 Wizardhat. All rights reserved.
//

#import "RBViewController.h"

@interface RBViewController ()

@end

@implementation RBViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    RBDisplayManager *dm = [[RBDisplayManager alloc] initWithFrame:self.view.bounds];
    //dm.userInteractionEnabled = false;
    [self.view addSubview:dm];
    
    /*UIImageView *imageHolder = [[UIImageView alloc] initWithFrame:CGRectMake(3, 20, 38, 80)];
    UIImage *image = [UIImage imageNamed:@"Red_card.png"];
    imageHolder.image = image;
    [self.view addSubview:imageHolder];
     
     UIImageView *brickAnim = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Red_Card.png"]];
     brickAnim.frame = CGRectMake(3, 20, 38, 80);
     [self.view addSubview:brickAnim];
*/
}

- (IBAction)handlePan:(UIPanGestureRecognizer *)recognizer {
    
    CGPoint translation = [recognizer translationInView:self.view];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.view];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

/*
card class creates



*/